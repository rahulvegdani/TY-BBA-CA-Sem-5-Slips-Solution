class Student:
    def __init__(self, roll_no, name, age, gender):
        self.roll_no = roll_no
        self.name = name
        self.age = age
        self.gender = gender

class Test(Student):
    def __init__(self, roll_no, name, age, gender, marks):
        super().__init__(roll_no, name, age, gender)
        self.marks = marks

    def calculate_total_marks(self):
        return sum(self.marks)

# Create three objects of the Test class
student1 = Test(101, "Alice", 18, "Female", [85, 90, 78])
student2 = Test(102, "Bob", 19, "Male", [92, 88, 75])
student3 = Test(103, "Charlie", 17, "Male", [78, 95, 82])

# Display details and total marks for each student
students = [student1, student2, student3]

for student in students:
    print(f"Roll No: {student.roll_no}")
    print(f"Name: {student.name}")
    print(f"Age: {student.age}")
    print(f"Gender: {student.gender}")
    print(f"Marks: {student.marks}")
    total_marks = student.calculate_total_marks()
    print(f"Total Marks: {total_marks}")
    print()
