abstract class Shape {
    abstract double area();
    abstract double volume();
}

class Cone extends Shape {
    private double radius;
    private double height;

    public Cone(double radius, double height) {
        this.radius = radius;
        this.height = height;
    }

    @Override
    double area() {
        double slantHeight = Math.sqrt(radius * radius + height * height);
        return Math.PI * radius * (radius + slantHeight);
    }

    @Override
    double volume() {
        return (1.0 / 3.0) * Math.PI * radius * radius * height;
    }
}

class Cylinder extends Shape {
    private double radius;
    private double height;

    public Cylinder(double radius, double height) {
        this.radius = radius;
        this.height = height;
    }

    @Override
    double area() {
        return 2.0 * Math.PI * radius * (radius + height);
    }

    @Override
    double volume() {
        return Math.PI * radius * radius * height;
    }
}

public class Q1B {
    public static void main(String[] args) {
        Cone cone = new Cone(3.0, 4.0);
        Cylinder cylinder = new Cylinder(3.0, 4.0);

        System.out.println("Area of Cone: " + cone.area());
        System.out.println("Volume of Cone: " + cone.volume());

        System.out.println("Area of Cylinder: " + cylinder.area());
        System.out.println("Volume of Cylinder: " + cylinder.volume());
    }
}
