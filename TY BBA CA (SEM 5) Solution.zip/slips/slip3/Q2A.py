# Sample dictionary
my_dict = {'apple': 10, 'banana': 20, 'cherry': 30}

# Key to check and replace
key_to_check = 'banana'
new_key = 'orange'
new_value = 40

# Check if the key exists in the dictionary
if key_to_check in my_dict:
    # Replace the key with a new key/value pair
    my_dict[new_key] = new_value
    del my_dict[key_to_check]
    print(f"The key '{key_to_check}' was replaced with '{new_key}': {my_dict}")
else:
    print(f"The key '{key_to_check}' does not exist in the dictionary.")
