import tkinter as tk

def convert_to_words(num):
    if num == 0:
        return "zero"

    ones = ["", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"]
    tens = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"]
    teens = ["ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"]
    words = ""

    if num >= 1000:
        words += ones[num // 1000] + " thousand "
        num %= 1000

    if num >= 100:
        words += ones[num // 100] + " hundred "
        num %= 100

    if num >= 10 and num <= 19:
        words += teens[num - 10] + " "
    elif num >= 20:
        words += tens[num // 10] + " "
        num %= 10

    if num >= 1 and num <= 9:
        words += ones[num] + " "

    return words.strip()

def convert_button_click():
    input_number = int(entry.get())
    words = convert_to_words(input_number)
    result_label.config(text=words)

# Create the main window
window = tk.Tk()
window.title("Number to Words Converter")

# Create and configure input entry widget
entry = tk.Entry(window, width=20)
entry.pack(pady=10)

# Create and configure convert button
convert_button = tk.Button(window, text="Convert", command=convert_button_click)
convert_button.pack()

# Create and configure result label
result_label = tk.Label(window, text="", font=("Arial", 16), wraplength=300)
result_label.pack(pady=10)

# Start the main loop
window.mainloop()
