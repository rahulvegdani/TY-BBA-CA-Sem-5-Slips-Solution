import TYBBACA.Student;
import TYBBACA.Teacher;

public class Q1B {
    public static void main(String[] args) {
        // Create an array of Student objects
        Student[] students = new Student[3];
        students[0] = new Student(101, "Alice", 85.5);
        students[1] = new Student(102, "Bob", 78.2);
        students[2] = new Student(103, "Charlie", 92.0);

        // Display student details
        for (Student student : students) {
            student.disp();
            System.out.println();
        }

        // Create a Teacher object
        Teacher javaTeacher = new Teacher(501, "Mr. Smith", "Java Programming");
        javaTeacher.disp();

        // Demonstrate finalize() method
        javaTeacher = null; // Mark the teacher object for garbage collection
        System.gc(); // Request garbage collection
    }
}
