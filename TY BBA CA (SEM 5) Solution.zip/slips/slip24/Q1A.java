import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Q1A {
    public static void main(String[] args) {
        String fileName = "input.txt"; // Change to the path of your file if needed

        int charCount = 0;
        int digitCount = 0;
        int spaceCount = 0;

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                for (char c : line.toCharArray()) {
                    charCount++;

                    if (Character.isDigit(c)) {
                        digitCount++;
                    } else if (Character.isWhitespace(c)) {
                        spaceCount++;
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading the file: " + e.getMessage());
        }

        System.out.println("Character count: " + charCount);
        System.out.println("Digit count: " + digitCount);
        System.out.println("Space count: " + spaceCount);
    }
}
