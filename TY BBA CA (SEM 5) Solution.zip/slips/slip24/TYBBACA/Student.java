package TYBBACA;

public class Student {
    private int Rno;
    private String SName;
    private double Per;

    public Student(int Rno, String SName, double Per) {
        this.Rno = Rno;
        this.SName = SName;
        this.Per = Per;
    }

    public void disp() {
        System.out.println("Student Details:");
        System.out.println("Roll Number: " + Rno);
        System.out.println("Student Name: " + SName);
        System.out.println("Percentage: " + Per + "%");
    }
}
