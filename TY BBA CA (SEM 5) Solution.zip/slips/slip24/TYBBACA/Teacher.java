package TYBBACA;

public class Teacher {
    private int TID;
    private String TName;
    private String Subject;

    public Teacher(int TID, String TName, String Subject) {
        this.TID = TID;
        this.TName = TName;
        this.Subject = Subject;
    }

    public void disp() {
        System.out.println("Teacher Details:");
        System.out.println("Teacher ID: " + TID);
        System.out.println("Teacher Name: " + TName);
        System.out.println("Teaching Subject: " + Subject);
    }
}
