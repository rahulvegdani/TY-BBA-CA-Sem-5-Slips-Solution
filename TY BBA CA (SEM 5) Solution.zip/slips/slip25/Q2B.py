class Calculator:
    def add(self, num1, num2):
        return num1 + num2

    def subtract(self, num1, num2):
        return num1 - num2

    def multiply(self, num1, num2):
        return num1 * num2

    def divide(self, num1, num2):
        if num2 == 0:
            return "Cannot divide by zero"
        return num1 / num2

# Create an instance of the Calculator class
calculator = Calculator()

# Perform basic calculator operations
num1 = float(input("Enter the first number: "))
num2 = float(input("Enter the second number: "))

print("1. Addition")
print("2. Subtraction")
print("3. Multiplication")
print("4. Division")

choice = int(input("Enter your choice (1/2/3/4): "))

if choice == 1:
    result = calculator.add(num1, num2)
    print(f"Result: {num1} + {num2} = {result}")
elif choice == 2:
    result = calculator.subtract(num1, num2)
    print(f"Result: {num1} - {num2} = {result}")
elif choice == 3:
    result = calculator.multiply(num1, num2)
    print(f"Result: {num1} * {num2} = {result}")
elif choice == 4:
    result = calculator.divide(num1, num2)
    print(f"Result: {num1} / {num2} = {result}")
else:
    print("Invalid choice")
