package slip25.Series;

public class CubeSeries {
    public static void generateSeries(int n) {
        System.out.print("Cube Series (First " + n + " terms): ");
        for (int i = 1; i <= n; i++) {
            int cube = i * i * i;
            System.out.print(cube + " ");
        }
        System.out.println();
    }
}
