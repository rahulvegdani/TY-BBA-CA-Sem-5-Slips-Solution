package slip25.Series;

public class SquareSeries {
    public static void generateSeries(int n) {
        System.out.print("Square Series (First " + n + " terms): ");
        for (int i = 1; i <= n; i++) {
            int square = i * i;
            System.out.print(square + " ");
        }
        System.out.println();
    }
}
