package slip25.Series;

public class Fibonacci {
    public static void generateSeries(int n) {
        int a = 0, b = 1;
        System.out.print("Fibonacci Series (First " + n + " terms): ");
        for (int i = 0; i < n; i++) {
            System.out.print(a + " ");
            int temp = a;
            a = b;
            b = temp + b;
        }
        System.out.println();
    }
}
