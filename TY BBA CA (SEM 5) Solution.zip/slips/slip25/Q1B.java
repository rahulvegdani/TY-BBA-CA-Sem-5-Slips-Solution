import slip25.Series.CubeSeries;
import slip25.Series.Fibonacci;
import slip25.Series.SquareSeries;

public class Q1B {
    public static void main(String[] args) {
        int n = 10; // Change this value to generate more or fewer terms

        Fibonacci.generateSeries(n);
        CubeSeries.generateSeries(n);
        SquareSeries.generateSeries(n);
    }
}
