//cmd line javac Q1A.java
//java Q1A 1 2 3

public class Q1A {
    public static boolean isArmstrong(int num) {
        int originalNum, remainder, result = 0;
        originalNum = num;

        while (originalNum != 0) {
            remainder = originalNum % 10;
            result += Math.pow(remainder, 3);
            originalNum /= 10;
        }

        return result == num;
    }

    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Please provide command line arguments.");
            return;
        }

        int n = args.length;
        int[] numbers = new int[n];
        int armstrongCount = 0;

        // Parse command line arguments to integers
        for (int i = 0; i < n; i++) {
            numbers[i] = Integer.parseInt(args[i]);
        }

        // Count Armstrong numbers and store them in a separate array
        for (int num : numbers) {
            if (isArmstrong(num)) {
                armstrongCount++;
            }
        }

        if (armstrongCount == 0) {
            System.out.println("No Armstrong numbers found in the provided numbers.");
        } else {
            int[] armstrongNumbers = new int[armstrongCount];
            int index = 0;

            for (int num : numbers) {
                if (isArmstrong(num)) {
                    armstrongNumbers[index++] = num;
                }
            }

            System.out.println("Armstrong Numbers:");
            for (int armstrong : armstrongNumbers) {
                System.out.print(armstrong + " ");
            }
        }
    }
}
