class InvalidDateException(Exception):
    pass

class Date:
    def __init__(self, day, month, year):
        self.day = day
        self.month = month
        self.year = year

    def is_valid_date(self):
        # Basic validation for day, month, and year
        if self.year < 1 or self.month < 1 or self.month > 12 or self.day < 1:
            return False

        # Check for valid day in the given month
        if self.month in [1, 3, 5, 7, 8, 10, 12]:
            return self.day <= 31
        elif self.month in [4, 6, 9, 11]:
            return self.day <= 30
        elif self.month == 2:
            # Check for leap year
            if (self.year % 4 == 0 and self.year % 100 != 0) or (self.year % 400 == 0):
                return self.day <= 29
            else:
                return self.day <= 28
        else:
            return False

    def accept_date(self):
        try:
            self.day = int(input("Enter day: "))
            self.month = int(input("Enter month: "))
            self.year = int(input("Enter year: "))

            if not self.is_valid_date():
                raise InvalidDateException("Invalid Date Exception: Date is not valid.")
        except ValueError:
            raise InvalidDateException("Invalid Date Exception: Invalid input. Please enter valid numbers for day, month, and year.")

    def display_date(self):
        print(f"Date: {self.day}/{self.month}/{self.year}")

try:
    date = Date(0, 0, 0)
    date.accept_date()
    date.display_date()
except InvalidDateException as e:
    print(e)
