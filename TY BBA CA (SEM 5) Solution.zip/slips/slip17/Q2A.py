import tkinter as tk

def convert_to_uppercase():
    input_text = entry.get()
    uppercase_text = input_text.upper()
    result_label.config(text=uppercase_text)

# Create the main window
root = tk.Tk()
root.title("Uppercase Converter")

# Create an entry field to enter text
entry = tk.Entry(root)
entry.pack(pady=10)

# Create a button to trigger the conversion
convert_button = tk.Button(root, text="Convert to Uppercase", command=convert_to_uppercase)
convert_button.pack()

# Create a label to display the result
result_label = tk.Label(root, text="", font=("Arial", 12))
result_label.pack(pady=10)

# Start the main loop
root.mainloop()
