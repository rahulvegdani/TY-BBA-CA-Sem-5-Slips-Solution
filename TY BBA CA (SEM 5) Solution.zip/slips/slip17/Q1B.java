import java.util.Scanner;

class Product {
    int pid;
    String pname;
    double price;
    int qty;

    // Constructor to initialize product details
    Product(int pid, String pname, double price, int qty) {
        this.pid = pid;
        this.pname = pname;
        this.price = price;
        this.qty = qty;
    }

    // Method to display product details
    void displayProductDetails() {
        System.out.println("Product ID: " + pid);
        System.out.println("Product Name: " + pname);
        System.out.println("Price per unit: $" + price);
        System.out.println("Quantity: " + qty);
    }

    // Method to calculate and return the total amount for the product
    double calculateTotalAmount() {
        return price * qty;
    }
}

public class Q1B {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the number of products: ");
        int n = input.nextInt();

        // Create an array of Product objects
        Product[] products = new Product[n];

        // Accept product details and store them in the array
        for (int i = 0; i < n; i++) {
            System.out.println("Enter details for Product " + (i + 1) + ":");
            System.out.print("Product ID: ");
            int pid = input.nextInt();
            input.nextLine(); // Consume newline
            System.out.print("Product Name: ");
            String pname = input.nextLine();
            System.out.print("Price per unit: $");
            double price = input.nextDouble();
            System.out.print("Quantity: ");
            int qty = input.nextInt();

            // Create a Product object and store it in the array
            products[i] = new Product(pid, pname, price, qty);
        }

        // Display product details and calculate the total amount for each product
        for (Product product : products) {
            System.out.println("\nProduct Details:");
            product.displayProductDetails();
            double totalAmount = product.calculateTotalAmount();
            System.out.println("Total Amount: $" + totalAmount);
        }

        input.close();
    }
}
