class InvalidAgeException extends Exception {
    public InvalidAgeException(String message) {
        super(message);
    }
}

public class Q1A {
    public static void main(String[] args) {
        try {
            if (args.length == 0) {
                throw new IllegalArgumentException("Please provide an age as a command-line argument.");
            }

            int age = Integer.parseInt(args[0]);
            checkEligibility(age);
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a valid age as a command-line argument.");
        } catch (InvalidAgeException e) {
            System.out.println("Sorry, you are not eligible to vote. " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void checkEligibility(int age) throws InvalidAgeException {
        if (age < 18) {
            throw new InvalidAgeException("You must be at least 18 years old to vote.");
        } else {
            System.out.println("Congratulations! You are eligible to vote.");
        }
    }
}
