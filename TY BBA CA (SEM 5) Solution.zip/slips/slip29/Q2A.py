import tkinter as tk
from math import pi

def calculate_volume():
    try:
        radius = float(radius_entry.get())
        volume = (4/3) * pi * (radius ** 3)
        result_label.config(text=f"Volume of Sphere: {volume:.2f} cubic units")
    except ValueError:
        result_label.config(text="Invalid input. Please enter a valid number.")

# Create the main application window
root = tk.Tk()
root.title("Sphere Volume Calculator")

# Create and configure GUI elements
radius_label = tk.Label(root, text="Enter the radius:")
radius_label.pack()

radius_entry = tk.Entry(root)
radius_entry.pack()

calculate_button = tk.Button(root, text="Calculate Volume", command=calculate_volume)
calculate_button.pack()

result_label = tk.Label(root, text="", font=("Helvetica", 12))
result_label.pack()

# Start the GUI event loop
root.mainloop()
