import java.applet.Applet;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Timer;

public class Q1B extends Applet implements ActionListener {
    private int x, y; // Ball's position
    private int xSpeed, ySpeed; // Ball's speed
    private Color[] colors; // Array of colors to change
    private int colorIndex; // Index of the current color
    private Timer timer;

    @Override
    public void init() {
        x = 100;
        y = 100;
        xSpeed = 2;
        ySpeed = 2;
        colorIndex = 0;
        colors = new Color[]{Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.ORANGE};
        setBackground(Color.WHITE);

        timer = new Timer(20, this);
        ((Applet) timer).start();
    }

    @Override
    public void paint(Graphics g) {
        g.setColor(colors[colorIndex]);
        g.fillOval(x, y, 50, 50); // Draw a circle (the ball)

        // Boundary checks for bouncing
        if (x < 0 || x > getWidth() - 50) {
            xSpeed = -xSpeed; // Reverse horizontal speed on collision
            changeColor();
        }
        if (y < 0 || y > getHeight() - 50) {
            ySpeed = -ySpeed; // Reverse vertical speed on collision
            changeColor();
        }

        // Update ball's position
        x += xSpeed;
        y += ySpeed;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        repaint();
    }

    private void changeColor() {
        colorIndex = (colorIndex + 1) % colors.length;
    }
}
