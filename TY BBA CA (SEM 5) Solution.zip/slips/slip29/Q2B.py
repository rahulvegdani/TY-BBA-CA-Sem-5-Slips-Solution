# Sample dictionary
sample_dict = {'b': 3, 'a': 1, 'd': 4, 'c': 2}

# Sort the dictionary by keys in ascending order
sorted_by_key_asc = dict(sorted(sample_dict.items()))

# Sort the dictionary by keys in descending order
sorted_by_key_desc = dict(sorted(sample_dict.items(), reverse=True))

# Sort the dictionary by values in ascending order
sorted_by_value_asc = dict(sorted(sample_dict.items(), key=lambda item: item[1]))

# Sort the dictionary by values in descending order
sorted_by_value_desc = dict(sorted(sample_dict.items(), key=lambda item: item[1], reverse=True))

# Print the sorted dictionaries
print("Sorted by Key (Ascending):", sorted_by_key_asc)
print("Sorted by Key (Descending):", sorted_by_key_desc)
print("Sorted by Value (Ascending):", sorted_by_value_asc)
print("Sorted by Value (Descending):", sorted_by_value_desc)
