def fibonacci_generator():
    a, b = 0, 1
    while True:
        yield a
        a, b = b, a + b

# Create a Fibonacci generator
fibonacci = fibonacci_generator()

# Generate and print the first 10 Fibonacci terms
for _ in range(10):
    print(next(fibonacci))
