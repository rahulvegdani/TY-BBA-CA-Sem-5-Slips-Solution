import java.io.File;

public class Q1B {
    public static void main(String[] args) {
        // Check if command line arguments are provided
        if (args.length == 0) {
            System.out.println("Please provide a list of file names.");
            return;
        }

        // Iterate through the provided file names
        for (String fileName : args) {
            File file = new File(fileName);

            // Check if the file exists
            if (!file.exists()) {
                System.out.println("File not found: " + fileName);
                continue;
            }

            // Check if the file has a .txt extension
            if (fileName.endsWith(".txt")) {
                // Delete the file with .txt extension
                if (file.delete()) {
                    System.out.println("Deleted file: " + fileName);
                } else {
                    System.out.println("Failed to delete file: " + fileName);
                }
            } else {
                // Display name, location, and size of remaining files
                System.out.println("File Name: " + fileName);
                System.out.println("Location: " + file.getAbsolutePath());
                System.out.println("Size (bytes): " + file.length());
                System.out.println();
            }
        }
    }
}
