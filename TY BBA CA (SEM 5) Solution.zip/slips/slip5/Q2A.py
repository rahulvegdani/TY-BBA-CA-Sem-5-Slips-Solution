class StringManipulator:
    def __init__(self):
        self.input_string = ""

    def get_String(self):
        self.input_string = input("Enter a string: ")

    def print_String(self):
        print("String in uppercase:", self.input_string.upper())

# Create an instance of the StringManipulator class
string_manipulator = StringManipulator()

# Call the get_String method to accept a string from the user
string_manipulator.get_String()

# Call the print_String method to print the string in uppercase
string_manipulator.print_String()
