public class Q1A {
    public static void main(String[] args) {
        int n = 5; // Number of rows

        // Outer loop for the rows
        for (int i = 1; i <= n; i++) {
            // Inner loop for printing numbers in each row
            for (int j = n - i + 1; j <= n; j++) {
                System.out.print(j + " ");
            }
            System.out.println(); // Move to the next line after each row
        }
    }
}
