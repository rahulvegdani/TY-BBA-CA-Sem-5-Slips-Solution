import java.util.Hashtable;
import java.util.Scanner;

public class Q1B {
    public static void main(String[] args) {
        Hashtable<String, String> citySTDHashtable = new Hashtable<>();

        // Populate the hashtable with city names and STD codes
        citySTDHashtable.put("New York", "212");
        citySTDHashtable.put("Los Angeles", "213");
        citySTDHashtable.put("Chicago", "312");
        citySTDHashtable.put("San Francisco", "415");
        citySTDHashtable.put("Boston", "617");

        // Display the details of the hashtable
        System.out.println("City STD Code Hashtable:");
        System.out.println(citySTDHashtable);

        // Search for a specific city and display its STD code
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a city to get its STD code: ");
        String searchCity = scanner.nextLine();

        String stdCode = citySTDHashtable.get(searchCity);

        if (stdCode != null) {
            System.out.println("STD code for " + searchCity + " is " + stdCode);
        } else {
            System.out.println("City not found in the hashtable.");
        }
    }
}
