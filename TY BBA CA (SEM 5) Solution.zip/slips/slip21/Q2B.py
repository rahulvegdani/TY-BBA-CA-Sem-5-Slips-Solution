# Original tuple of string values
original_tuple = (('333', '33'), ('1416', '55'))

# Convert the original tuple to a new tuple of integers
new_tuple = tuple(tuple(int(value) for value in inner) for inner in original_tuple)

# Print the new tuple
print("Original tuple values:", original_tuple)
print("New tuple values:", new_tuple)
