import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Q1A {
    public static void main(String[] args) {
        // Replace "input.txt" with the path to your input file.
        String filePath = "input.txt";

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;

            while ((line = br.readLine()) != null) {
                // Split the line into words using space as a delimiter
                String[] words = line.split(" ");

                // Iterate through the words and display them in reverse order
                for (String word : words) {
                    String reversedWord = reverseWord(word);
                    System.out.print(reversedWord + " ");
                }
                System.out.println(); // Print a new line after each line of text
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Helper function to reverse a word
    private static String reverseWord(String word) {
        StringBuilder reversed = new StringBuilder(word);
        return reversed.reverse().toString();
    }
}
