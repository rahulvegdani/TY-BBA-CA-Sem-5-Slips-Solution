def remove_odd_index_characters(input_string):
    result = ""
    for index, char in enumerate(input_string):
        if index % 2 == 0:
            result += char
    return result

# Input a string from the user
user_input = input("Enter a string: ")

# Call the user-defined function to remove odd index characters
modified_string = remove_odd_index_characters(user_input)

# Display the modified string
print("Original String:", user_input)
print("Modified String:", modified_string)
