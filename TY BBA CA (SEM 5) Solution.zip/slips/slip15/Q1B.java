import java.applet.Applet;
import java.awt.*;

public class Q1B extends Applet {
    public void paint(Graphics g) {
        // Set the background color to light blue
        setBackground(Color.lightGray);

        // Draw the face (circle)
        g.setColor(Color.yellow);
        g.fillOval(100, 100, 200, 200);

        // Draw the eyes (circles)
        g.setColor(Color.white);
        g.fillOval(150, 150, 50, 50);
        g.fillOval(250, 150, 50, 50);

        // Draw the mouth (arc)
        g.setColor(Color.red);
        g.drawArc(150, 200, 150, 100, 0, -180);
    }
}
