import java.util.Scanner;

public class Q1A {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Define an array of names
        String[] names = {"Sharlin", "Rahul", "Ojas", "Joel", "Aanchal", "Mohsin", "Kishan"};

        // Prompt the user to enter a name to search
        System.out.print("Enter a name to search: ");
        String searchName = scanner.nextLine();

        // Call the searchNameInArray function to search for the name
        int index = searchNameInArray(names, searchName);

        if (index != -1) {
            // Name found, display its index
            System.out.println("Name found at index: " + index);
        } else {
            // Name not found, display appropriate message
            System.out.println("Name not found in the array.");
        }

        scanner.close();
    }

    public static int searchNameInArray(String[] names, String searchName) {
        for (int i = 0; i < names.length; i++) {
            if (names[i].equals(searchName)) {
                return i; // Name found, return its index
            }
        }
        return -1; // Name not found, return -1
    }
}
