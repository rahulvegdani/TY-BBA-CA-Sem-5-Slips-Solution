class Student:
    def __init__(self, student_name, marks):
        self.student_name = student_name
        self.marks = marks

    def display_original_values(self):
        print("Original Student Name:", self.student_name)
        print("Original Marks:", self.marks)

    def modify_values(self, new_name, new_marks):
        self.student_name = new_name
        self.marks = new_marks

    def display_modified_values(self):
        print("Modified Student Name:", self.student_name)
        print("Modified Marks:", self.marks)

# Create an instance of the Student class
student = Student("John", 85)

# Display the original values
print("Original Values:")
student.display_original_values()

# Modify the attribute values
student.modify_values("Alice", 92)

# Display the modified values
print("\nModified Values:")
student.display_modified_values()
