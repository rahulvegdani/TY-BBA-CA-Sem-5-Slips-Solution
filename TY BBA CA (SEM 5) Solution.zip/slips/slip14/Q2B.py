def caesar_cipher(text, shift):
    cipher_text = ""

    for char in text:
        if char.isalpha():
            # Determine whether the character is uppercase or lowercase
            is_upper = char.isupper()

            # Convert the character to its ASCII code
            char_code = ord(char)

            # Apply the Caesar cipher shift
            char_code = ((char_code - 65 + shift) % 26) + 65 if is_upper else ((char_code - 97 + shift) % 26) + 97

            # Convert the ASCII code back to a character
            cipher_char = chr(char_code)

            # Append the cipher character to the result
            cipher_text += cipher_char
        else:
            # If the character is not alphabetic, keep it as is
            cipher_text += char

    return cipher_text

# Input plain text and shift value
plain_text = input("Enter plain text: ")
shift_value = int(input("Enter shift value: "))

# Encrypt the plain text
cipher_text = caesar_cipher(plain_text, shift_value)

# Display the plain text and cipher text
print("Plain Text:", plain_text)
print("Cipher Text:", cipher_text)
