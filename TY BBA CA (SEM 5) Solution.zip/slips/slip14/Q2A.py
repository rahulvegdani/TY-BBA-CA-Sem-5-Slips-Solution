import tkinter as tk
from tkinter import Label, Entry, Button

# Function to calculate the surface area and volume of a cylinder
def calculate_cylinder():
    try:
        # Get the values entered by the user
        radius = float(radius_entry.get())
        height = float(height_entry.get())

        # Calculate the surface area and volume
        surface_area = 2 * 3.1416 * radius * (radius + height)
        volume = 3.1416 * radius**2 * height

        # Display the results
        surface_area_label.config(text=f"Surface Area: {surface_area:.2f}")
        volume_label.config(text=f"Volume: {volume:.2f}")

    except ValueError:
        surface_area_label.config(text="Invalid input. Please enter numeric values.")

# Create the main window
window = tk.Tk()
window.title("Cylinder Calculator")

# Create labels and entry fields for radius and height
radius_label = Label(window, text="Enter Radius:")
radius_label.pack()
radius_entry = Entry(window)
radius_entry.pack()

height_label = Label(window, text="Enter Height:")
height_label.pack()
height_entry = Entry(window)
height_entry.pack()

# Create a button to calculate the surface area and volume
calculate_button = Button(window, text="Calculate", command=calculate_cylinder)
calculate_button.pack()

# Create labels to display the results
surface_area_label = Label(window, text="")
surface_area_label.pack()
volume_label = Label(window, text="")
volume_label.pack()

# Start the Tkinter main loop
window.mainloop()
