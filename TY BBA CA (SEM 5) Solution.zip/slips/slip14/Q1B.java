import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;

import java.awt.event.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

public class Q1B extends JFrame implements ActionListener {

    JLabel eno, ename, sal;
    JTextField enoval, enameval, salval;
    JButton submit;
    JPanel p;

    Q1B() {

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout(FlowLayout.CENTER));
        p = new JPanel(new GridLayout(4, 2, -90, 5));

        eno = new JLabel("Employee Number");
        enoval = new JTextField(20);

        ename = new JLabel("Employee Name");
        enameval = new JTextField(20);

        sal = new JLabel("Salary");
        salval = new JTextField(20);

        submit = new JButton("Submit");

        submit.addActionListener(this);
        p.setSize(100, 100);

        p.add(eno);
        p.add(enoval);
        p.add(ename);
        p.add(enameval);
        p.add(sal);
        p.add(salval);

        p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        setSize(420, 420);
        add(p);
        add(submit);
        setResizable(false);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submit) {
            enoval.setEditable(false);
            enameval.setEditable(false);
            salval.setEditable(false);
            JFrame f = new JFrame();
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            f.setSize(420, 420);
            p.setBackground(new Color(0x12345));
            p.setForeground(Color.WHITE);
            f.setLayout(new FlowLayout(FlowLayout.CENTER));

            eno.setForeground(Color.WHITE);
            ename.setForeground(Color.WHITE);
            sal.setForeground(Color.WHITE);
            enoval.setFont(new Font("Cambria", Font.PLAIN, 16));
            enameval.setFont(new Font("Cambria", Font.PLAIN, 16));
            salval.setFont(new Font("Cambria", Font.PLAIN, 16));

            UIManager.put("TextField.font", new Font("Cambria",

                    Font.PLAIN, 14));

            UIManager.put("Label.font", new Font("Cambria",

                    Font.BOLD, 16));

            f.add(new JLabel("<HTML><U>Employee Information</U></HTML>"));
            f.add(p);
            f.pack();
            f.setResizable(false);
            f.setVisible(true);
            // dispose();
        }
    }

    public static void main(String[] args) {
        new Q1B();
    }
}