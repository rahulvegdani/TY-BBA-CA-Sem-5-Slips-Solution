import java.awt.*; // for flow layout
import javax.swing.*;
import java.awt.event.*;

public class Q1B implements ActionListener{

JFrame f;
JPanel p, group;
JLabel l;
JTextField t;
JButton b;
DefaultListModel<String> mul = new DefaultListModel<>();
JList<String> arr = new JList<String>(mul);
int num;

Q1B(){
f = new JFrame();
f.setLayout(new FlowLayout());
f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
f.setSize(400,400);

p = new JPanel();
p.setPreferredSize(new Dimension(300,300));
p.setLayout(new FlowLayout());

group = new JPanel();

l = new JLabel("Enter a Number");
t = new JTextField(10);
t.addActionListener(this);

b = new JButton("Display Multiplication Table");
b.addActionListener(this);

group.add(l);
group.add(t);
p.add(group);
p.add(b);
f.add(p);
f.setVisible(true);
}

public void actionPerformed(ActionEvent e){
String x = t.getText();
num = Integer.parseInt(x);
System.out.println("num "+num);
mul.clear();
for(int i=1; i<=10; i++){
mul.addElement(num+" * "+i+" = "+(num*i));
}
// b.setDisabledButton(true);
arr.setFixedCellWidth(210);
// arr.setFixedCellHeight(200);
// arr.setPreferredSize(new Dimension(200,200));

p.add(arr);
f.add(p);
f.setVisible(true);
}

public static void main(String[] args) {
new Q1B();
}
}