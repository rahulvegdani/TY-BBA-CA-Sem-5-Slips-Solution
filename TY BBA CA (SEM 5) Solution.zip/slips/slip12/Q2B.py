# Function to count repeated characters in a string
def count_repeated_characters(input_string):
    char_count = {}  # Initialize an empty dictionary to store character frequencies

    # Iterate through each character in the input string
    for char in input_string:
        # If the character is already in the dictionary, increment its count
        if char in char_count:
            char_count[char] += 1
        # If the character is not in the dictionary, add it with a count of 1
        else:
            char_count[char] = 1

    # Print the characters with their frequencies
    for char, count in char_count.items():
        if count > 1:
            print(f"'{char}' occurs {count} times")

# Input from the user
user_input = input("Enter a string: ")

# Call the function to count repeated characters
count_repeated_characters(user_input)
