import tkinter as tk
from tkinter import font

def change_font_style():
    font_name = font_name_entry.get()
    font_size = int(font_size_entry.get())
    is_bold = bold_var.get()

    label.config(font=(font_name, font_size, "bold" if is_bold else "normal"))

# Create the main window
root = tk.Tk()
root.title("Font Style Changer")

# Create and pack a label
label = tk.Label(root, text="Hello, Font Style!", font=("Arial", 12))
label.pack(pady=20)

# Font Name Entry
font_name_label = tk.Label(root, text="Font Name:")
font_name_label.pack()
font_name_entry = tk.Entry(root)
font_name_entry.pack()

# Font Size Entry
font_size_label = tk.Label(root, text="Font Size:")
font_size_label.pack()
font_size_entry = tk.Entry(root)
font_size_entry.pack()

# Bold Checkbox
bold_var = tk.BooleanVar()
bold_check = tk.Checkbutton(root, text="Bold", variable=bold_var)
bold_check.pack()

# Apply Button
apply_button = tk.Button(root, text="Apply", command=change_font_style)
apply_button.pack()

# Start the main loop
root.mainloop()
