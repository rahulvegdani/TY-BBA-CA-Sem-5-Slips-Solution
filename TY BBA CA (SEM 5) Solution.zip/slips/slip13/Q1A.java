import java.util.ArrayList;
import java.util.Scanner;

public class Q1A {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create an ArrayList to store integers
        ArrayList<Integer> numbersList = new ArrayList<>();

        // Input 'n' integers from the user
        System.out.print("Enter the number of integers (n): ");
        int n = scanner.nextInt();

        System.out.println("Enter " + n + " integers:");
        for (int i = 0; i < n; i++) {
            int num = scanner.nextInt();
            numbersList.add(num);
        }

        // Display the elements of ArrayList in reverse order
        System.out.println("Elements in reverse order:");
        for (int i = numbersList.size() - 1; i >= 0; i--) {
            System.out.println(numbersList.get(i));
        }

        scanner.close();
    }
}
