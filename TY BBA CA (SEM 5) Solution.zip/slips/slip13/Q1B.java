import java.util.Scanner;

public class Q1B {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Ask the user for their name
        System.out.print("Please enter your name: ");
        String userName = scanner.nextLine();

        // Convert the user's name to uppercase
        String upperCaseName = userName.toUpperCase();

        // Greet the user with the uppercase name
        System.out.println("Hello, " + upperCaseName + ", nice to meet you!");

        scanner.close();
    }
}
