try:
    # Input a positive integer
    number = int(input("Enter a positive integer: "))

    # Check if the number is positive
    if number > 0:
        print(f"You entered a positive integer: {number}")
    else:
        print("The input is not a positive integer.")

except ValueError:
    print("Invalid input. Please enter a valid positive integer.")
