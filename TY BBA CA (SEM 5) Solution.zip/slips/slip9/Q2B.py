import tkinter as tk

def check_number():
    number = int(entry.get())
    result = ""

    # Check for Prime Number
    is_prime = True
    if number > 1:
        for i in range(2, int(number**0.5) + 1):
            if number % i == 0:
                is_prime = False
                break
    else:
        is_prime = False

    # Check for Perfect Number
    is_perfect = sum([i for i in range(1, number) if number % i == 0]) == number

    # Check for Armstrong Number
    str_number = str(number)
    order = len(str_number)
    is_armstrong = sum(int(digit) ** order for digit in str_number) == number

    # Build the result string based on the selected radio button
    if selected_option.get() == 1:
        result += "Prime " if is_prime else "Not Prime "
    elif selected_option.get() == 2:
        result += "Perfect " if is_perfect else "Not Perfect "
    elif selected_option.get() == 3:
        result += "Armstrong " if is_armstrong else "Not Armstrong "

    result_var.set(result)

# Create the main window
window = tk.Tk()
window.title("Number Checker")

# Create and place widgets
tk.Label(window, text="Enter a Number:").pack(pady=10)
entry = tk.Entry(window)
entry.pack(pady=10)

# Radio buttons
selected_option = tk.IntVar()

prime_radio = tk.Radiobutton(window, text="Prime", variable=selected_option, value=1)
prime_radio.pack(pady=5)

perfect_radio = tk.Radiobutton(window, text="Perfect", variable=selected_option, value=2)
perfect_radio.pack(pady=5)

armstrong_radio = tk.Radiobutton(window, text="Armstrong", variable=selected_option, value=3)
armstrong_radio.pack(pady=5)

check_button = tk.Button(window, text="Check Number", command=check_number)
check_button.pack(pady=10)

result_var = tk.StringVar()
result_label = tk.Label(window, textvariable=result_var, font=("Courier", 12))
result_label.pack(pady=10)

# Start the main loop
window.mainloop()
