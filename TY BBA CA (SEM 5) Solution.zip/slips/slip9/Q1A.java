public class Q1A {
    public static void main(String[] args) {
        int n = 4; // Change the value of 'n' to adjust the number of rows

        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= i; j++) {
                // Print 0 for even positions and 1 for odd positions
                if ((i + j) % 2 == 0) {
                    System.out.print("0 ");
                } else {
                    System.out.print("1 ");
                }
            }
            System.out.println(); // Move to the next line after each row
        }
    }
}
