package slip9;

public class invalid_details {

}
