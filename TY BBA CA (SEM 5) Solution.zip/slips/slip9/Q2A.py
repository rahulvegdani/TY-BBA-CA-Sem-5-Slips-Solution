class reverse:
    def __init__(self):
        self.text = ""
        self.result = ""

    def get(self):
        self.text = input("Enter a string : ")

    def execute(self):
        for word in self.text.split():
            self.result += word[::-1] + " "

    def display(self):
        print (f"Reverse of string word by word is: {self.result}")

string_obj = reverse()
string_obj.get()
string_obj.execute()
string_obj.display()