import java.awt.*;
import java.awt.event.*;

public class Q1A extends Frame {
    public Q1A() {
        // Set the title of the frame
        super("TYBBACA");

        // Set the background color to red
        setBackground(Color.RED);

        // Create a Close button
        Button closeButton = new Button("Close");

        // Add an ActionListener to the Close button
        closeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close the frame
            }
        });

        // Add the Close button to the frame
        add(closeButton, BorderLayout.SOUTH);

        // Add a WindowAdapter to handle the close button click
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0); // Exit the program
            }
        });

        // Set the size of the frame
        setSize(400, 300);

        // Make the frame visible
        setVisible(true);
    }

    public static void main(String[] args) {
        new Q1A();
    }
}
