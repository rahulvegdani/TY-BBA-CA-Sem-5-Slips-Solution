class Circle:
    def __init__(self, radius):
        self.radius = radius

    def calculate_area(self):
        return 3.14159265359 * self.radius * self.radius

    def calculate_circumference(self):
        return 2 * 3.14159265359 * self.radius

# Input the radius from the user
radius = float(input("Enter the radius of the circle: "))

# Create a Circle object with the given radius
circle = Circle(radius)

# Calculate and display the area and circumference
print(f"Area of the circle: {circle.calculate_area()}")
print(f"Circumference of the circle: {circle.calculate_circumference()}")
