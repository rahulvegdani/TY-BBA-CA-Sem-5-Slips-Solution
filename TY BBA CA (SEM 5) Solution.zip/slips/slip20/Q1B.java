import java.util.LinkedList;
import java.util.Iterator;
import java.util.ListIterator;

public class Q1B {
    public static void main(String[] args) {
        // Create a linked list of names
        LinkedList<String> namesList = new LinkedList<>();
        namesList.add("CPP");
        namesList.add("Java");
        namesList.add("Python");
        namesList.add("PHP");

        // Display the contents of the list using an iterator
        System.out.println("Contents of the list using an Iterator:");
        Iterator<String> iterator = namesList.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }

        // Display the contents of the list in reverse order using a ListIterator
        System.out.println("\nContents of the list in reverse order using a ListIterator:");
        ListIterator<String> listIterator = namesList.listIterator(namesList.size());
        while (listIterator.hasPrevious()) {
            System.out.println(listIterator.previous());
        }
    }
}
