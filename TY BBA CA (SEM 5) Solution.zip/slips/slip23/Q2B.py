import math

class Circle:
    def __init__(self, radius):
        self.radius = radius

    def __add__(self, other_circle):
        if isinstance(other_circle, Circle):
            return Circle(self.radius + other_circle.radius)
        else:
            raise ValueError("Addition is only supported between Circle objects.")

    def calculate_area(self):
        return math.pi * self.radius**2

# Input radius from the user for two circles
radius1 = float(input("Enter the radius of the first circle: "))
radius2 = float(input("Enter the radius of the second circle: "))

# Create Circle objects
circle1 = Circle(radius1)
circle2 = Circle(radius2)

# Add the radii of the two circles using operator overloading
resulting_circle = circle1 + circle2

# Calculate the area of the resulting circle
area = resulting_circle.calculate_area()

# Display the result
print("The area of the resulting circle is:", area)
