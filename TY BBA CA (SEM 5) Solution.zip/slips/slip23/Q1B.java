import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;

public class Q1B extends JFrame
{
        public Q1B()
        {
                JMenuBar mb1=new JMenuBar();
                setJMenuBar(mb1);

                JMenu m1=new JMenu("File");
                JMenu m2=new JMenu("Edit");
                JMenu m3=new JMenu("Search");

                JTextArea ta=new JTextArea();

                mb1.add(m1);
                mb1.add(m2);
                mb1.add(m3);

                m1.add(new JMenuItem("New",new ImageIcon("new.jpg")));
                m1.add(new JMenuItem("Open",new ImageIcon("open.jpg")));
                m1.add(new JMenuItem("Save",new ImageIcon("save.jpg")));
                m1.addSeparator();
                m1.add(new JMenuItem("Page Setup",new ImageIcon("pagesetup.jpg")));
                m1.add(new JMenuItem("Print",new ImageIcon("print.jpg")));

                m2.add(new JMenuItem("Undo",new ImageIcon("undo.jpg")));
                m2.add(new JMenuItem("Redo",new ImageIcon("redo.jpg")));
                m2.addSeparator();
                m2.add(new JMenuItem("Cut",new ImageIcon("cut.jpg")));
                m2.add(new JMenuItem("Copy",new ImageIcon("copy.jpg")));
                m2.add(new JMenuItem("Paste",new ImageIcon("paste.jpg")));

                m3.add(new JMenuItem("Find",new ImageIcon("find.jpg")));
                this.getContentPane().add(ta);
        }
        public static void main(String str[])
        {
                Q1B md1=new Q1B();
                md1.setVisible(true);
                md1.setSize(300,300);
        }
}