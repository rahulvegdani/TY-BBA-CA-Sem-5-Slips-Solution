import tkinter as tk
from tkinter import font

def change_font_style():
    font_name = font_name_entry.get()
    font_size = int(font_size_entry.get())
    is_bold = bold_var.get()

    label_font = font.Font(family=font_name, size=font_size, weight="bold" if is_bold else "normal")
    label.config(font=label_font)

# Create the main window
root = tk.Tk()
root.title("Label Font Changer")

# Create label
label = tk.Label(root, text="Sample Text")
label.pack(pady=20)

# Font name entry
font_name_label = tk.Label(root, text="Font Name:")
font_name_label.pack()
font_name_entry = tk.Entry(root)
font_name_entry.pack()

# Font size entry
font_size_label = tk.Label(root, text="Font Size:")
font_size_label.pack()
font_size_entry = tk.Entry(root)
font_size_entry.pack()

# Bold checkbox
bold_var = tk.IntVar()
bold_check = tk.Checkbutton(root, text="Bold", variable=bold_var)
bold_check.pack()

# Apply font button
apply_font_button = tk.Button(root, text="Apply Font", command=change_font_style)
apply_font_button.pack()

root.mainloop()
