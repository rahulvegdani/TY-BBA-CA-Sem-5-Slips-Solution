import tkinter as tk

def alter_sentence():
    input_text = input_entry.get()
    altered_text = ""

    for char in input_text:
        if char.isalpha():
            if char.islower():
                altered_text += char.upper()
            else:
                altered_text += char.lower()
        elif char.isdigit():
            altered_text += '?'
        elif char.isspace():
            altered_text += '*'
        else:
            altered_text += char

    output_label.config(text=altered_text)

# Create the main application window
root = tk.Tk()
root.title("Sentence Alteration")

# Create and configure GUI elements
input_label = tk.Label(root, text="Enter a sentence:")
input_label.pack()

input_entry = tk.Entry(root)
input_entry.pack()

alter_button = tk.Button(root, text="Alter", command=alter_sentence)
alter_button.pack()

output_label = tk.Label(root, text="", wraplength=400)
output_label.pack()

# Start the GUI event loop
root.mainloop()
