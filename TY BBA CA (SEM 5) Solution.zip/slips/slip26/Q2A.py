# Anonymous function to calculate the area of a square
square_area = lambda side: side**2

# Anonymous function to calculate the area of a rectangle
rectangle_area = lambda length, width: length * width

# Input from the user for square
side_length = float(input("Enter the side length of the square: "))
square_result = square_area(side_length)
print(f"Area of the square: {square_result}")

# Input from the user for rectangle
length = float(input("Enter the length of the rectangle: "))
width = float(input("Enter the width of the rectangle: "))
rectangle_result = rectangle_area(length, width)
print(f"Area of the rectangle: {rectangle_result}")
