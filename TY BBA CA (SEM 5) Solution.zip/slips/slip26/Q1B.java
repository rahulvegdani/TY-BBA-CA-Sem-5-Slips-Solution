import java.applet.Applet;
import java.awt.Graphics;
import java.awt.Color;

public class Q1B extends Applet {
    public void paint(Graphics g) {
        // Set background color
        setBackground(Color.cyan);

        // Draw the temple
        g.setColor(Color.gray);
        g.fillRect(100, 100, 200, 300);

        // Draw the roof
        int[] roofX = {100, 200, 300};
        int[] roofY = {100, 20, 100};
        g.setColor(Color.red);
        g.fillPolygon(roofX, roofY, 3);

        // Draw the door
        g.setColor(Color.orange);
        g.fillRect(170, 200, 60, 200);

        // Draw the windows
        g.setColor(Color.yellow);
        g.fillRect(120, 220, 40, 60);
        g.fillRect(240, 220, 40, 60);
    }
}
