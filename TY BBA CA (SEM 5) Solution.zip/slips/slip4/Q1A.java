import java.util.Scanner;

public class Q1A {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String inputString = scanner.nextLine();
        scanner.close();

        System.out.println("Alternate characters from the string:");

        for (int i = 0; i < inputString.length(); i += 2) {
            char currentChar = inputString.charAt(i);
            System.out.print(currentChar);
        }
    }
}
