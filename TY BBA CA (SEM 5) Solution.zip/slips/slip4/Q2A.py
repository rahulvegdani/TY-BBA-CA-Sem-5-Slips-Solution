import tkinter as tk
import random
import time

def change_color():
    # Generate random RGB values for the background color
    red = random.randint(0, 255)
    green = random.randint(0, 255)
    blue = random.randint(0, 255)

    # Convert RGB values to hexadecimal color code
    color_code = f'#{red:02X}{green:02X}{blue:02X}'

    # Change the background color of the label
    label.config(bg=color_code)

    # Schedule the next color change after 2 seconds
    root.after(2000, change_color)

# Create the main window
root = tk.Tk()
root.title("Changing Background Color")

# Create a label with an initial background color
label = tk.Label(root, text="Changing Background", width=30, height=10, bg="white")
label.pack(expand="true", fill="both")

# Start the color change loop
change_color()

# Start the GUI main loop
root.mainloop()
