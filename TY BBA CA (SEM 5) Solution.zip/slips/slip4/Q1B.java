import java.awt.BorderLayout;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.*;
import java.applet.*;
import java.awt.event.*;

@SuppressWarnings("removal")
public class Q1B extends Applet implements ActionListener{
Panel p, p1, p2, p3, p4;
Button operator[] = new Button[5]; // 5 operators
Button number[] = new Button[10]; // 0-9 numbers
Button clr = new Button("Clear"); // Clear Button
Font f; // set font
JTextField input; // for inputing numbers

double num1 = 0, num2 = 0, result = 0;
String op="", temp1="", temp2="";

//Function to add features to the frame
public void init(){

f = new Font("Helvetica", Font.BOLD, 14);
setFont(f);
setBackground(new Color(0x123456));
setSize(400,400);
p = new Panel(); //container
p1 = new Panel(); // for textbox
p2 = new Panel(); // operations
p3 = new Panel(); // numbers
p4 = new Panel(); // for clear

/*------------------ TEXT FIELD ------------------ */
input = new JTextField(17);
input.setFont(f);
input.setHorizontalAlignment(SwingConstants.RIGHT); //to strt typing from right

input.setEditable(false); // so that it doesn't take input
p1.add(input);

/*------------------ OPERATORS ------------------ */
p2.setLayout(new FlowLayout(FlowLayout.CENTER));
p2.setPreferredSize(new Dimension(60,100));

operator[0]=new Button("+");
operator[1]=new Button("-");
operator[2]=new Button("*");
operator[3]=new Button("/");
operator[4]=new Button("=");

for(int i=0; i<5; i++){
p2.add(operator[i]);
operator[i].setPreferredSize(new Dimension(50,25));
operator[i].addActionListener(this);
}

/*------------------ NUMBERS ------------------ */

for(int i=9; i>=0; i--){
number[i] = new Button(String.valueOf(i));
number[i].setPreferredSize(new Dimension(50,25));
number[i].addActionListener(this);
p3.add(number[i]);
}

/*------------------ CLEAR BUTTON ------------------ */

// Button clr=new Button("Clear");
clr.setPreferredSize(new Dimension(50,25));
clr.addActionListener(this);
p4.add(clr);

// adding every panel to the main panel p
p.setBackground(Color.lightGray);
p.setLayout(new BorderLayout(10,10));
p.setPreferredSize(new Dimension(250,260));

p.add(p1,BorderLayout.NORTH);
p.add(p4,BorderLayout.SOUTH);
p.add(p2,BorderLayout.EAST);
p.add(p3,BorderLayout.CENTER);
add(p); // adding main container to frame
setVisible(true);
}

// @Override
public void actionPerformed(ActionEvent e) {
String buttonval = e.getActionCommand();
char ch = buttonval.charAt(0);

if(ch>='0' && ch<='9'){
if (op.equals("")){ // if there is operator then it is num2

temp1 = temp1 + ch;
}
else{
temp2 = temp2 + ch;
}
input.setText(temp1+op+temp2);
}

for(int i=0; i<5; i++){
if(e.getSource() == operator[i]){
if(e.getSource()==operator[4]){ //which is '='
num1 = Double.parseDouble(temp1);
num2 = Double.parseDouble(temp2);

switch(op) {
case "+":
result=num1+num2;
break;
case "-":
result=num1-num2;
break;
case "*":
result=num1*num2;
break;
case "/":
if(num2==0){
temp1 = temp2 = "";
input.setText("Division by Zero!");
}
else
result=num1/num2;
break;

}
if(num2==0.0 && op.equals("/")){
input.setText("Division by Zero!");
}
else{
input.setText(String.valueOf(result));
temp2 = op = "";
temp1=String.valueOf(result);
}
}
else{
if(temp2.equals("") && !temp1.equals("")){ //if temp2 is not there then only else disable
op = e.getActionCommand();
input.setText(temp1+op);
}
}
}
}
if(e.getSource()==clr){
input.setText("");
temp1 = op = temp2 = "";
}
}

}