class Employee:
    def __init__(self):
        self.id = ""
        self.name = ""
        self.department = ""
        self.salary = 0.0

    def accept(self):
        self.id = input("Enter Employee ID: ")
        self.name = input("Enter Employee Name: ")
        self.department = input("Enter Department: ")
        self.salary = float(input("Enter Salary: "))

    def display(self):
        print(f"Employee ID: {self.id}")
        print(f"Employee Name: {self.name}")
        print(f"Department: {self.department}")
        print(f"Salary: {self.salary}")


class Manager(Employee):
    def __init__(self):
        super().__init__()
        self.bonus = 0.0

    def accept(self):
        super().accept()
        self.bonus = float(input("Enter Bonus: "))

    def display(self):
        super().display()
        print(f"Bonus: {self.bonus}")


n = int(input("Enter the number of managers: "))
managers = []

for i in range(n):
    print(f"Enter details for Manager {i + 1}:")
    manager = Manager()
    manager.accept()
    managers.append(manager)

# Find the manager with the maximum total salary (salary + bonus)
max_total_salary = 0
max_salary_manager = None

for manager in managers:
    total_salary = manager.salary + manager.bonus
    if total_salary > max_total_salary:
        max_total_salary = total_salary
        max_salary_manager = manager

print("\nManager with the Maximum Total Salary:")
if max_salary_manager is not None:
    max_salary_manager.display()
    print(f"Total Salary (Salary + Bonus): {max_total_salary}")
else:
    print("No managers to display.")
