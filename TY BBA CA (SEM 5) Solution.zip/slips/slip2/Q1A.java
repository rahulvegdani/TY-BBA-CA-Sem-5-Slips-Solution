import java.util.Scanner;

public class Q1A {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String inputString = scanner.nextLine();
        scanner.close();

        System.out.println("Vowels in the string:");

        // Convert the input string to lowercase to handle both uppercase and lowercase vowels
        inputString = inputString.toLowerCase();

        // Loop through each character in the string and check for vowels
        for (int i = 0; i < inputString.length(); i++) {
            char currentChar = inputString.charAt(i);
            if (currentChar == 'a' || currentChar == 'e' || currentChar == 'i' || currentChar == 'o' || currentChar == 'u') {
                System.out.print(currentChar + " ");
            }
        }
    }
}
