def count_upper_lower(string):
    upper_count = 0
    lower_count = 0

    for char in string:
        if char.isupper():
            upper_count += 1
        elif char.islower():
            lower_count += 1

    return upper_count, lower_count

# Get input from the user
input_string = input("Enter a string: ")

# Call the function to count uppercase and lowercase letters
upper, lower = count_upper_lower(input_string)

# Display the results
print("Number of uppercase letters:", upper)
print("Number of lowercase letters:", lower)
