import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Q1B {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Mouse Event Handler");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        // Create a JPanel to hold components
        JPanel panel = new JPanel();
        frame.add(panel);

        // Create a JTextField to display the mouse click position
        JTextField textField = new JTextField(20);
        panel.add(textField);

        // Create a MouseAdapter to handle mouse events
        MouseAdapter mouseAdapter = new MouseAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                // Display the mouse cursor position when it's moved
                textField.setText("Mouse Position: X=" + e.getX() + ", Y=" + e.getY());
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                // Display the mouse click position in the TextField
                textField.setText("Mouse Clicked: X=" + e.getX() + ", Y=" + e.getY());
            }
        };

        // Add the MouseAdapter to the panel
        panel.addMouseListener(mouseAdapter);
        panel.addMouseMotionListener(mouseAdapter);

        frame.setVisible(true);
    }
}
