# Function to take user input for a tuple
def input_tuple():
    input_str = input("Enter a tuple of numbers separated by spaces: ")
    try:
        user_tuple = tuple(map(int, input_str.split()))
        return user_tuple
    except ValueError:
        print("Invalid input. Please enter numbers separated by spaces.")
        return input_tuple()

# Get user input for three tuples
print("Enter elements for the first tuple:")
tuple1 = input_tuple()

print("Enter elements for the second tuple:")
tuple2 = input_tuple()

print("Enter elements for the third tuple:")
tuple3 = input_tuple()

# Compute the element-wise sum using list comprehension
result_tuple = tuple(sum(x) for x in zip(tuple1, tuple2, tuple3))

# Print the result
print("Element-wise sum of the given tuples:", result_tuple)
