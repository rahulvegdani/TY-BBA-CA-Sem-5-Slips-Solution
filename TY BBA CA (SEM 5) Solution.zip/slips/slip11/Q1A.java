public class Q1A {
    public static void main(String[] args) {
        if (args.length < 3) {
            System.out.println("Usage: java CommandLineCalculator <operation> <operand1> <operand2>");
            System.exit(1);
        }

        String operation = args[0].toLowerCase();
        double operand1 = Double.parseDouble(args[1]);
        double operand2 = Double.parseDouble(args[2]);

        double result = 0.0;

        switch (operation) {
            case "addition":
                result = operand1 + operand2;
                break;
            case "subtraction":
                result = operand1 - operand2;
                break;
            case "multiplication":
                result = operand1 * operand2;
                break;
            case "division":
                if (operand2 != 0) {
                    result = operand1 / operand2;
                } else {
                    System.out.println("Error: Division by zero is not allowed.");
                    System.exit(1);
                }
                break;
            default:
                System.out.println("Invalid operation. Please choose one of: addition, subtraction, multiplication, division.");
                System.exit(1);
        }

        System.out.println("Result: " + result);
    }
}
