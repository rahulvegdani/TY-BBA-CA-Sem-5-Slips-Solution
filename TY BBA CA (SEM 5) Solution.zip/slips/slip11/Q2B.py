import tkinter as tk

def change_color(color):
    root.configure(bg=color)

def create_menu():
    menu = tk.Menu(root)
    root.config(menu=menu)

    color_menu = tk.Menu(menu, tearoff=0)
    menu.add_cascade(label="Colors Menu", menu=color_menu)
    color_menu.add_command(label="Red", command=lambda: change_color("red"))
    color_menu.add_command(label="Green", command=lambda: change_color("green"))
    color_menu.add_command(label="Blue", command=lambda: change_color("blue"))
    color_menu.add_command(label="Yellow", command=lambda: change_color("yellow"))
    color_menu.add_command(label="White", command=lambda: change_color("white"))

root = tk.Tk()
root.title("Color Changer")
root.geometry("400x300")

create_menu()

label = tk.Label(root, text="Select a color from the menu")
label.pack(pady=50)

root.mainloop()
