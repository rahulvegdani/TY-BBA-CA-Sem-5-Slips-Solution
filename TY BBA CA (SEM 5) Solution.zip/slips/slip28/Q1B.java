import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

public class Q1B {
    private JFrame frame;
    private DefaultTableModel tableModel;
    private JTable employeeTable;
    private JTextField enoField, enameField, salaryField;
    private JButton addButton;

    public Q1B() {
        frame = new JFrame("Employee Details");

        // Create a table model with columns for Eno, Ename, and Salary
        tableModel = new DefaultTableModel();
        tableModel.addColumn("Eno");
        tableModel.addColumn("Ename");
        tableModel.addColumn("Salary");

        // Create the JTable with the table model
        employeeTable = new JTable(tableModel);

        // Create input fields and button
        enoField = new JTextField(5);
        enameField = new JTextField(15);
        salaryField = new JTextField(10);
        addButton = new JButton("Add Employee");

        // Create a panel for input fields and button
        JPanel inputPanel = new JPanel();
        inputPanel.add(new JLabel("Eno:"));
        inputPanel.add(enoField);
        inputPanel.add(new JLabel("Ename:"));
        inputPanel.add(enameField);
        inputPanel.add(new JLabel("Salary:"));
        inputPanel.add(salaryField);
        inputPanel.add(addButton);

        // Add action listener to the button
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addEmployee();
            }
        });

        // Create and configure the main frame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.add(new JScrollPane(employeeTable), BorderLayout.CENTER);
        frame.add(inputPanel, BorderLayout.SOUTH);
        frame.pack();
        frame.setVisible(true);
    }

    private void addEmployee() {
        String eno = enoField.getText();
        String ename = enameField.getText();
        String salary = salaryField.getText();

        // Check if all fields are filled
        if (eno.isEmpty() || ename.isEmpty() || salary.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Add the employee details to the table
        tableModel.addRow(new Object[]{eno, ename, salary});

        // Clear the input fields
        enoField.setText("");
        enameField.setText("");
        salaryField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Q1B();
            }
        });
    }
}
