import tkinter as tk

def add_course():
    course = course_entry.get()
    if course:
        courses_listbox.insert(tk.END, course)
        course_entry.delete(0, tk.END)

def remove_course():
    selected_index = courses_listbox.curselection()
    if selected_index:
        courses_listbox.delete(selected_index)

# Create the main application window
root = tk.Tk()
root.title("Computer Science Courses")

# Create and configure GUI elements
course_label = tk.Label(root, text="Enter a course:")
course_label.pack()

course_entry = tk.Entry(root)
course_entry.pack()

add_button = tk.Button(root, text="Add Course", command=add_course)
add_button.pack()

remove_button = tk.Button(root, text="Remove Course", command=remove_course)
remove_button.pack()

courses_listbox = tk.Listbox(root)
courses_listbox.pack()

# Add some initial courses
initial_courses = ["Computer Science 101", "Data Structures", "Algorithms", "Database Management"]
for course in initial_courses:
    courses_listbox.insert(tk.END, course)

# Start the GUI event loop
root.mainloop()
