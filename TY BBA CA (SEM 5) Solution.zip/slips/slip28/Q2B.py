# Function to merge two lists into a list of tuples
def merge_lists_into_tuples(list1, list2):
    # Use zip to create pairs of elements from the two lists
    merged_tuples = list(zip(list1, list2))
    return merged_tuples

# Input two lists from the user
list1 = input("Enter elements of the first list separated by spaces: ").split()
list2 = input("Enter elements of the second list separated by spaces: ").split()

# Convert the input values to the desired data type (e.g., integers)
list1 = [int(item) for item in list1]
list2 = [int(item) for item in list2]

# Check if the lists have the same length
if len(list1) != len(list2):
    print("Error: The two lists must have the same length.")
else:
    # Merge the lists into a list of tuples
    merged_tuples = merge_lists_into_tuples(list1, list2)

    # Print the merged list of tuples
    print("Merged List of Tuples:", merged_tuples)
