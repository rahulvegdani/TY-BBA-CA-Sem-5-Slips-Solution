public class Q1A {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Usage: java Q1A <list_of_integers>");
            return;
        }

        int count = 0;

        for (String arg : args) {
            try {
                // Attempt to parse the argument as an integer
                int num = Integer.parseInt(arg);
                count++;
            } catch (NumberFormatException e) {
                // Ignore non-integer arguments
            }
        }

        System.out.println("Number of integers in the list: " + count);
    }
}
