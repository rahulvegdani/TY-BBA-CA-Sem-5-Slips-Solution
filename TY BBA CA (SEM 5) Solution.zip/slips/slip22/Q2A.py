class StringRepeater:
    def __init__(self, input_string):
        self.input_string = input_string

    def __mul__(self, n):
        if isinstance(n, int):
            return self.input_string * n
        else:
            raise ValueError("The multiplier 'n' must be an integer")

# Accept input from the user
input_string = input("Enter a string: ")
n = int(input("Enter the number of times to repeat the string: "))

# Create a StringRepeater object
repeater = StringRepeater(input_string)

# Use the overloaded * operator to repeat the string and display the result
result = repeater * n

print("Result:", result)
