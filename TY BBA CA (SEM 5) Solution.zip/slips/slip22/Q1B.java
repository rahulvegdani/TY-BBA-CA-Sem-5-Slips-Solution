import java.io.File;
import java.io.IOException;
public class Q1B {
    public static void main(String[] args) {
        // Create a file
        File file = new File("newfile.txt");
        try {
            file.createNewFile();
            System.out.println("File created successfully");
        } catch (IOException e) {
            System.out.println("Error creating file");
            e.printStackTrace();
        }
        // Rename a file
        File oldFile = new File("oldfile.txt");
        File newFile = new File("newfile.txt");
        if (oldFile.renameTo(newFile)) {
            System.out.println("File renamed successfully");
        } else {
            System.out.println("Error renaming file");
        }
        // Delete a file
        if (file.delete()) {
            System.out.println("File deleted successfully");
        } else {
            System.out.println("Error deleting file");
        }
        // Display path of a file
        System.out.println("File path: " + file.getAbsolutePath());
    }
}
