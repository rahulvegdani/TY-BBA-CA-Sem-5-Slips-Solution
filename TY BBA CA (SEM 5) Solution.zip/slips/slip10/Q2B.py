class ValidParentheses:
    def is_valid(self, s):
        stack = []
        brackets = {')': '(', '}': '{', ']': '['}

        for char in s:
            if char in brackets.values():
                stack.append(char)
            elif char in brackets.keys():
                if not stack or stack.pop() != brackets[char]:
                    return False
            else:
                # Invalid character in the string
                return False

        return len(stack) == 0

# Example usage:
validator = ValidParentheses()
input_string = input("Enter a string of parentheses, curly braces, and square brackets: ")

if validator.is_valid(input_string):
    print("Valid")
else:
    print("Invalid")
