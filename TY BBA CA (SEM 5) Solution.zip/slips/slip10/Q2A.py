import tkinter as tk
from tkinter import messagebox

def display_alert():
    messagebox.showinfo("Alert", "Button pressed!")

# Create the main window
root = tk.Tk()
root.title("Alert Button")

# Create a button
button = tk.Button(root, text="Press Me", command=display_alert)
button.pack(pady=20)

# Start the Tkinter main loop
root.mainloop()
