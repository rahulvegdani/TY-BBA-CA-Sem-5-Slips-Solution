import java.util.HashMap;
import java.util.Map;

public class Q1A {
    public static void main(String[] args) {
        String inputString = "Hello, World!";
        Map<Character, Integer> charFrequencyMap = new HashMap<>();

        // Convert the string to lowercase to make the counting case-insensitive
        inputString = inputString.toLowerCase();

        // Iterate through the characters in the string
        for (char character : inputString.toCharArray()) {
            // Skip non-alphabetic characters
            if (!Character.isLetter(character)) {
                continue;
            }

            // Increment the frequency count for the character in the map
            charFrequencyMap.put(character, charFrequencyMap.getOrDefault(character, 0) + 1);
        }

        // Display character frequencies
        for (Map.Entry<Character, Integer> entry : charFrequencyMap.entrySet()) {
            System.out.println("Character: " + entry.getKey() + ", Frequency: " + entry.getValue());
        }
    }
}
