import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.text.DecimalFormat;

public class Q1B extends JFrame implements ActionListener {

    private JLabel principalLabel, rateLabel, timeLabel, totalAmountLabel, interestAmountLabel;
    private JTextField principalField, rateField, timeField, totalAmountField, interestAmountField;
    private JButton calculateButton, clearButton, closeButton;

    public Q1B() {
        setTitle("Compound Interest Calculator");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the frame

        principalLabel = new JLabel("Principal Amount:");
        rateLabel = new JLabel("Annual Interest Rate (%):");
        timeLabel = new JLabel("Time (Years):");
        totalAmountLabel = new JLabel("Total Amount:");
        interestAmountLabel = new JLabel("Interest Amount:");

        principalField = new JTextField(10);
        rateField = new JTextField(10);
        timeField = new JTextField(10);
        totalAmountField = new JTextField(10);
        interestAmountField = new JTextField(10);
        interestAmountField.setEditable(false); // Make this field read-only

        calculateButton = new JButton("Calculate");
        clearButton = new JButton("Clear");
        closeButton = new JButton("Close");

        // Create panels for organizing components
        JPanel inputPanel = new JPanel(new GridLayout(3, 2));
        inputPanel.add(principalLabel);
        inputPanel.add(principalField);
        inputPanel.add(rateLabel);
        inputPanel.add(rateField);
        inputPanel.add(timeLabel);
        inputPanel.add(timeField);

        JPanel resultPanel = new JPanel(new GridLayout(2, 2));
        resultPanel.add(totalAmountLabel);
        resultPanel.add(totalAmountField);
        resultPanel.add(interestAmountLabel);
        resultPanel.add(interestAmountField);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(calculateButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(closeButton);

        // Add action listeners to buttons
        calculateButton.addActionListener(this);
        clearButton.addActionListener(this);
        closeButton.addActionListener(this);

        // Create the main content pane
        Container contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());
        contentPane.add(inputPanel, BorderLayout.NORTH);
        contentPane.add(resultPanel, BorderLayout.CENTER);
        contentPane.add(buttonPanel, BorderLayout.SOUTH);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == calculateButton) {
            // Get input values
            double principal = Double.parseDouble(principalField.getText());
            double rate = Double.parseDouble(rateField.getText()) / 100; // Convert to decimal
            double time = Double.parseDouble(timeField.getText());

            // Calculate compound interest
            double n = 12; // Assuming interest is compounded monthly
            double totalAmount = principal * Math.pow(1 + (rate / n), n * time);
            double interestAmount = totalAmount - principal;

            // Format and display results
            DecimalFormat decimalFormat = new DecimalFormat("#.##");
            totalAmountField.setText(decimalFormat.format(totalAmount));
            interestAmountField.setText(decimalFormat.format(interestAmount));
        } else if (ae.getSource() == clearButton) {
            // Clear input and result fields
            principalField.setText("");
            rateField.setText("");
            timeField.setText("");
            totalAmountField.setText("");
            interestAmountField.setText("");
        } else if (ae.getSource() == closeButton) {
            // Close the application
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Q1B calculator = new Q1B();
            calculator.setVisible(true);
        });
    }
}
