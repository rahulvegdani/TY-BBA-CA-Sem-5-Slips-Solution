import java.util.Scanner;

public class Q1A {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a number
        System.out.print("Enter a number: ");
        int number = scanner.nextInt();

        // Calculate the sum of digits using recursion
        int sum = calculateSumOfDigits(number);

        // Display the result
        System.out.println("Sum of digits: " + sum);

        scanner.close();
    }

    public static int calculateSumOfDigits(int number) {
        // Base case: If the number is a single digit, return it
        if (number < 10) {
            return number;
        }

        // Recursive case: Calculate the sum of digits
        int lastDigit = number % 10;
        int remainingDigits = number / 10;
        return lastDigit + calculateSumOfDigits(remainingDigits);
    }
}
