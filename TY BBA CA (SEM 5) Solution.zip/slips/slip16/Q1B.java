import java.util.Scanner;

class Employee {
    private String name;

    public Employee(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}

public class Q1B {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input the number of employees (n)
        System.out.print("Enter the number of employees (n): ");
        int n = scanner.nextInt();

        // Create an array of Employee objects
        Employee[] employees = new Employee[n];

        // Input employee names
        for (int i = 0; i < n; i++) {
            System.out.print("Enter the name of employee " + (i + 1) + ": ");
            String name = scanner.next();
            employees[i] = new Employee(name);
        }

        // Sort the employee names in ascending order
        sortEmployeeNames(employees);

        // Display the sorted employee names
        System.out.println("Sorted Employee Names:");
        for (Employee employee : employees) {
            System.out.println(employee.getName());
        }

        scanner.close();
    }

    public static void sortEmployeeNames(Employee[] employees) {
        // Bubble sort algorithm to sort employee names
        int n = employees.length;
        boolean swapped;
        do {
            swapped = false;
            for (int i = 1; i < n; i++) {
                if (employees[i - 1].getName().compareTo(employees[i].getName()) > 0) {
                    // Swap if the current name is lexicographically greater than the next name
                    Employee temp = employees[i - 1];
                    employees[i - 1] = employees[i];
                    employees[i] = temp;
                    swapped = true;
                }
            }
        } while (swapped);
    }
}
