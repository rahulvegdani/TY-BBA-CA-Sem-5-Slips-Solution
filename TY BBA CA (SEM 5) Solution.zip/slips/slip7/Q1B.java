import java.util.Scanner;

class CricketPlayer {
    int playerId;
    String playerName;
    int totalRuns;
    int inningsPlayed;
    int notOutTimes;

    public CricketPlayer(int playerId, String playerName, int totalRuns, int inningsPlayed, int notOutTimes) {
        this.playerId = playerId;
        this.playerName = playerName;
        this.totalRuns = totalRuns;
        this.inningsPlayed = inningsPlayed;
        this.notOutTimes = notOutTimes;
    }

    public double calculateAverage() {
        if (inningsPlayed - notOutTimes == 0) {
            return 0.0;
        }
        return (double) totalRuns / (inningsPlayed - notOutTimes);
    }
}

public class Q1B {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of cricket players (n): ");
        int n = scanner.nextInt();

        // Create an array to store n cricket players
        CricketPlayer[] players = new CricketPlayer[n];

        // Input player details
        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details for Player " + (i + 1) + ":");
            System.out.print("Player ID: ");
            int playerId = scanner.nextInt();
            System.out.print("Player Name: ");
            String playerName = scanner.next();
            System.out.print("Total Runs: ");
            int totalRuns = scanner.nextInt();
            System.out.print("Innings Played: ");
            int inningsPlayed = scanner.nextInt();
            System.out.print("Not Out Times: ");
            int notOutTimes = scanner.nextInt();

            players[i] = new CricketPlayer(playerId, playerName, totalRuns, inningsPlayed, notOutTimes);
        }

        // Calculate average for all players
        double totalAverage = 0;
        int maxAverageIndex = 0;
        double maxAverage = 0;

        for (int i = 0; i < n; i++) {
            double average = players[i].calculateAverage();
            totalAverage += average;

            if (average > maxAverage) {
                maxAverage = average;
                maxAverageIndex = i;
            }
        }

        double overallAverage = totalAverage / n;

        // Display player with maximum average
        System.out.println("\nAverage Runs for All Players: " + overallAverage);
        System.out.println("Player with Maximum Average:");
        System.out.println("Player ID: " + players[maxAverageIndex].playerId);
        System.out.println("Player Name: " + players[maxAverageIndex].playerName);
        System.out.println("Average Runs: " + maxAverage);

        scanner.close();
    }
}
