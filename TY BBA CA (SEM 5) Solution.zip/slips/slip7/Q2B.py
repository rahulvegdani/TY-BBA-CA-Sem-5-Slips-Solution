import tkinter as tk
import random
import string

def generate_password():
    length = int(length_entry.get())
    characters = string.ascii_letters  # includes both upper and lower case letters
    password = ''.join(random.choice(characters) for _ in range(length))
    result_var.set(password)

# Create the main window
window = tk.Tk()
window.title("Random Password Generator")

# Create and place widgets
tk.Label(window, text="Password Length:").pack(pady=10)
length_entry = tk.Entry(window)
length_entry.pack(pady=10)

generate_button = tk.Button(window, text="Generate Password", command=generate_password)
generate_button.pack(pady=10)

result_var = tk.StringVar()
result_label = tk.Label(window, textvariable=result_var, font=("Courier", 12))
result_label.pack(pady=10)

# Start the main loop
window.mainloop()
