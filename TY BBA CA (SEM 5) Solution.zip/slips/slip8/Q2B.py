class MyClass:
    def get_string(self):
        self. MyStr=input("Enter any String: ")
    def print_string(self):
        s=self.MyStr
        print("Upper Case: " , s.upper())

        cnt=len(s)
        i=cnt-1
        RevStr=""
        while(i >= 0):
            RevStr=RevStr + s[i]
            i=i-1
        print("Reverse & Lower case:" , RevStr.lower())
a=MyClass()
a.get_string()
a.print_string()