import java.io.File;

public class Q1B {
    public static void main(String[] args) {
        // Replace this with the path to your directory
        String directoryPath = "C:\\Users\\Lenovo\\OneDrive\\Desktop\\college\\third year (SEM 5)\\slips\\slip8";

        File directory = new File(directoryPath);

        // Check if the directory exists
        if (directory.exists() && directory.isDirectory()) {
            // List all files in the directory
            File[] files = directory.listFiles();

            if (files != null) {
                System.out.println("Files with .txt extension in the directory:");

                // Iterate through the files and display those with .txt extension
                for (File file : files) {
                    if (file.isFile() && file.getName().endsWith(".txt")) {
                        System.out.println(file.getName());
                    }
                }
            } else {
                System.out.println("No files found in the directory.");
            }
        } else {
            System.out.println("The specified directory does not exist.");
        }
    }
}
