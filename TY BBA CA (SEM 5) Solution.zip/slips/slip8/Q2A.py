def find_repeated_items(my_tuple):
    item_count = {}
    repeated_items = []

    for item in my_tuple:
        if item in item_count:
            item_count[item] += 1
        else:
            item_count[item] = 1

    for item, count in item_count.items():
        if count > 1:
            repeated_items.append(item)

    return repeated_items

# Example usage:
my_tuple = (1, 2, 2, 3, 4, 4, 5, 6, 6)
result = find_repeated_items(my_tuple)
print("Repeated items:", result)
