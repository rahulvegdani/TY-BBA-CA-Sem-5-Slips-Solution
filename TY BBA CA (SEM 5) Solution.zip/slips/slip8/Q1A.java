// Define the Shape interface
interface Shape {
    double area();
}

// Create a Circle class that implements the Shape interface
class Circle implements Shape {
    private final double radius;

    public Circle(double radius) {
        this.radius = radius;
    }

    @Override
    public final double area() {
        return Math.PI * radius * radius;
    }
}

// Create a Sphere class that implements the Shape interface
class Sphere implements Shape {
    private final double radius;

    public Sphere(double radius) {
        this.radius = radius;
    }

    @Override
    public final double area() {
        return 4 * Math.PI * radius * radius;
    }
}

public class Q1A {
    public static void main(String[] args) {
        Circle circle = new Circle(5.0);
        Sphere sphere = new Sphere(3.0);

        System.out.println("Area of Circle: " + circle.area());
        System.out.println("Area of Sphere: " + sphere.area());
    }
}
