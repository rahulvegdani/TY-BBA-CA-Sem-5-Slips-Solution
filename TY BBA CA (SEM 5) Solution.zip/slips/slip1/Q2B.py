import tkinter as tk
from tkinter import messagebox
from datetime import date

# Function to calculate age from birthdate
def calculate_age():
    birthdate = entry.get()

    try:
        birthdate = [int(x) for x in birthdate.split('/')]
        birthdate = date(birthdate[2], birthdate[0], birthdate[1])
        today = date.today()
        age = today.year - birthdate.year - ((today.month, today.day) < (birthdate.month, birthdate.day))
        messagebox.showinfo("Age", f"Your age is {age} years.")
    except ValueError:
        messagebox.showerror("Error", "Invalid date format. Please use MM/DD/YYYY.")

# Create the main window
root = tk.Tk()
root.title("Age Calculator")

# Create a label and an entry widget
label = tk.Label(root, text="Enter your birthdate (MM/DD/YYYY):")
label.pack()
entry = tk.Entry(root)
entry.pack()

# Create a button to calculate age
button = tk.Button(root, text="Calculate Age", command=calculate_age)
button.pack()

# Start the GUI main loop
root.mainloop()
