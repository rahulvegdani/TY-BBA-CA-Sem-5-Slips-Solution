import java.io.*;

public class Q1B {
    public static void main(String[] args) {
        // Input and output file paths
        String inputFile = "input.txt";
        String outputFile = "output.txt";

        try {
            // Create FileReader and FileWriter objects
            FileReader reader = new FileReader(inputFile);
            FileWriter writer = new FileWriter(outputFile);

            int character;

            // Read characters from the input file and write non-numeric characters to the output file
            while ((character = reader.read()) != -1) {
                char ch = (char) character;
                if (!Character.isDigit(ch)) {
                    writer.write(ch);
                }
            }

            // Close the file readers and writers
            reader.close();
            writer.close();

            System.out.println("Non-numeric data copied successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
