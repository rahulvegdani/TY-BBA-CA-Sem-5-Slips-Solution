public class Q1A {
    public static void main(String[] args) {
        // Loop to display characters from 'A' to 'Z'
        for (char ch = 'A'; ch <= 'Z'; ch++) {
            System.out.print(ch + " ");
        }
    }
}
