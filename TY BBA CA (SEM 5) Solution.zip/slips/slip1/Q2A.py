# Function to remove duplicates from a list
def remove_duplicates(input_list):
    # Convert the list to a set to remove duplicates
    unique_set = set(input_list)
    # Convert the set back to a list
    result_list = list(unique_set)
    return result_list

# Input: Accept n numbers in a list
n = int(input("Enter the number of elements in the list: "))
input_list = []

for i in range(n):
    element = int(input(f"Enter element {i + 1}: "))
    input_list.append(element)

# Remove duplicates from the list
result = remove_duplicates(input_list)

# Display the list without duplicates
print("List after removing duplicates:", result)
