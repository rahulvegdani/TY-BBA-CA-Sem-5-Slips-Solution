import java.util.Scanner;

// Custom exception class
class OutOfRangeException extends Exception {
    public OutOfRangeException(String message) {
        super(message);
    }
}

public class Q1A {
    // Static method to calculate and display factors or throw an exception
    public static void calculateFactors(int number) throws OutOfRangeException {
        if (number > 1000) {
            throw new OutOfRangeException("Number is out of Range");
        } else {
            System.out.print("Factors of " + number + ": ");
            for (int i = 1; i <= number; i++) {
                if (number % i == 0) {
                    System.out.print(i + " ");
                }
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int number = scanner.nextInt();

        try {
            calculateFactors(number);
        } catch (OutOfRangeException e) {
            System.out.println("Exception: " + e.getMessage());
        }

        scanner.close();
    }
}
