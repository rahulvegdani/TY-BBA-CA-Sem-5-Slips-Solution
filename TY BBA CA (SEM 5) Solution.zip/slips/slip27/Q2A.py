# Sample list of tuples
list_of_tuples = [(1, 'a'), (2, 'b'), (3, 'c')]

# Unzip the list of tuples into individual lists
unzipped_lists = list(zip(*list_of_tuples))

# Separate the unzipped lists
first_list, second_list = unzipped_lists

# Print the unzipped lists
print("First list:", first_list)
print("Second list:", second_list)
