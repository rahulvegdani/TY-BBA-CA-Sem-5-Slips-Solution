import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

public class Q1B {
    private JFrame frame;
    private JTextField directoryTextField;
    private JList<String> fileList;
    private DefaultListModel<String> listModel;

    public Q1B() {
        frame = new JFrame("File List App");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        directoryTextField = new JTextField(30); // Set the number of columns (width)
        JButton listButton = new JButton("List Files");
        listModel = new DefaultListModel<>();
        fileList = new JList<>(listModel);

        JPanel inputPanel = new JPanel();
        inputPanel.add(new JLabel("Enter Directory: "));
        inputPanel.add(directoryTextField);
        inputPanel.add(listButton);

        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(new JScrollPane(fileList), BorderLayout.CENTER);

        listButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                listFilesAndDirectories();
            }
        });

        frame.setVisible(true);
    }

    private void listFilesAndDirectories() {
        String directoryPath = directoryTextField.getText();
        File directory = new File(directoryPath);

        if (directory.exists() && directory.isDirectory()) {
            listModel.clear(); // Clear previous list

            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    listModel.addElement(file.getName());
                }
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Invalid directory path!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Q1B();
            }
        });
    }
}
