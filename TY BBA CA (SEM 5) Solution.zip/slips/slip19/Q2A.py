import tkinter as tk

# Function to calculate and display the multiplication table
def display_multiplication_table():
    try:
        num = int(entry.get())  # Get the user input as an integer
        result_text.config(text="Multiplication Table for " + str(num))

        # Generate and display the multiplication table
        table = ""
        for i in range(1, 11):
            table += str(num) + " x " + str(i) + " = " + str(num * i) + "\n"

        table_text.config(text=table)
    except ValueError:
        result_text.config(text="Invalid input. Please enter a valid number.")

# Create the main window
window = tk.Tk()
window.title("Multiplication Table")

# Create and configure widgets
label = tk.Label(window, text="Enter a number:")
entry = tk.Entry(window)
calculate_button = tk.Button(window, text="Calculate", command=display_multiplication_table)
result_text = tk.Label(window, text="")
table_text = tk.Label(window, text="")

# Place widgets in the window
label.pack()
entry.pack()
calculate_button.pack()
result_text.pack()
table_text.pack()

# Start the GUI event loop
window.mainloop()
