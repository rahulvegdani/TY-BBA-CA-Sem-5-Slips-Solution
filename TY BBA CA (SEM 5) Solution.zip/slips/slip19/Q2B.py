import math

class Shape:
    def __init__(self):
        pass

    def calculate_area(self):
        pass

    def calculate_volume(self):
        pass

class Square(Shape):
    def __init__(self, length):
        self.length = length

    def calculate_area(self):
        return self.length ** 2

    def calculate_volume(self):
        return None  # Square is a 2D shape, so it doesn't have volume

class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius

    def calculate_area(self):
        return math.pi * self.radius ** 2

    def calculate_volume(self):
        return None  # Circle is a 2D shape, so it doesn't have volume

# Take user input to choose the shape and its properties
while True:
    print("Choose a shape:")
    print("1. Square")
    print("2. Circle")
    choice = input("Enter your choice (1/2): ")

    if choice == '1':
        length = float(input("Enter the length of the square: "))
        square = Square(length)
        print(f"Area of the square: {square.calculate_area()}")
        break
    elif choice == '2':
        radius = float(input("Enter the radius of the circle: "))
        circle = Circle(radius)
        print(f"Area of the circle: {circle.calculate_area()}")
        break
    else:
        print("Invalid choice. Please enter 1 or 2.")
