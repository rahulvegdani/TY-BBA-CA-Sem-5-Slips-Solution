import java.applet.Applet;
import java.awt.event.*;
import java.awt.*;

public class Q1B extends Applet implements MouseMotionListener, KeyListener {
    private int x, y;

    public void init() {
        addMouseMotionListener(this);
        addKeyListener(this);
        x = y = 0;
        setFocusable(true);
    }

    public void paint(Graphics g) {
        g.drawString("Mouse X: " + x, 20, 20);
        g.drawString("Mouse Y: " + y, 20, 40);
    }

    public void mouseMoved(MouseEvent e) {
        x = e.getX();
        y = e.getY();
        repaint();
    }

    public void mouseDragged(MouseEvent e) {
        // Not used in this example
    }

    public void keyPressed(KeyEvent e) {
        // Not used in this example
    }

    public void keyReleased(KeyEvent e) {
        // Not used in this example
    }

    public void keyTyped(KeyEvent e) {
        x = 0;
        y = 0;
        repaint();
    }
}
