import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Q1B extends JFrame implements ActionListener {
    private JTextField firstNameField, lastNameField, addressField, mobileNumberField;
    private JRadioButton maleRadioButton, femaleRadioButton;
    private JCheckBox computerCheckBox, sportsCheckBox, musicCheckBox;

    public Q1B() {
        setTitle("Personal Information Form");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a panel for the form
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 10, 5, 10); // Padding

        // Create and configure form elements
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("First Name:"), gbc);
        gbc.gridx = 1;
        gbc.gridy = 0;
        firstNameField = new JTextField(20);
        formPanel.add(firstNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("Last Name:"), gbc);
        gbc.gridx = 1;
        gbc.gridy = 1;
        lastNameField = new JTextField(20);
        formPanel.add(lastNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(new JLabel("Address:"), gbc);
        gbc.gridx = 1;
        gbc.gridy = 2;
        addressField = new JTextField(20);
        formPanel.add(addressField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(new JLabel("Mobile Number:"), gbc);
        gbc.gridx = 1;
        gbc.gridy = 3;
        mobileNumberField = new JTextField(20);
        formPanel.add(mobileNumberField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(new JLabel("Gender:"), gbc);
        gbc.gridx = 1;
        gbc.gridy = 4;
        maleRadioButton = new JRadioButton("Male");
        femaleRadioButton = new JRadioButton("Female");
        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(maleRadioButton);
        genderGroup.add(femaleRadioButton);
        JPanel genderPanel = new JPanel();
        genderPanel.add(maleRadioButton);
        genderPanel.add(femaleRadioButton);
        formPanel.add(genderPanel, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        formPanel.add(new JLabel("Interests:"), gbc);
        gbc.gridx = 1;
        gbc.gridy = 5;
        computerCheckBox = new JCheckBox("Computer");
        sportsCheckBox = new JCheckBox("Sports");
        musicCheckBox = new JCheckBox("Music");
        JPanel interestsPanel = new JPanel();
        interestsPanel.setLayout(new GridLayout(1, 3));
        interestsPanel.add(computerCheckBox);
        interestsPanel.add(sportsCheckBox);
        interestsPanel.add(musicCheckBox);
        formPanel.add(interestsPanel, gbc);

        // Create the Submit button
        gbc.gridx = 1;
        gbc.gridy = 6;
        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(this);
        formPanel.add(submitButton, gbc);

        // Create the Reset button
        gbc.gridx = 0;
        gbc.gridy = 6;
        JButton resetButton = new JButton("Reset");
        resetButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                clearForm();
            }
        });
        formPanel.add(resetButton, gbc);

        // Add the form panel to the frame
        add(formPanel);

        setLocationRelativeTo(null); // Center the window
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        // Handle the submit button click event
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String address = addressField.getText();
        String mobileNumber = mobileNumberField.getText();
        String gender = maleRadioButton.isSelected() ? "Male" : "Female";
        String interests = "";
        if (computerCheckBox.isSelected()) interests += "Computer, ";
        if (sportsCheckBox.isSelected()) interests += "Sports, ";
        if (musicCheckBox.isSelected()) interests += "Music, ";

        // Remove trailing comma and space from interests
        interests = interests.replaceAll(", $", "");

        // Display the collected information in a dialog
        String message = "First Name: " + firstName + "\n" +
                "Last Name: " + lastName + "\n" +
                "Address: " + address + "\n" +
                "Mobile Number: " + mobileNumber + "\n" +
                "Gender: " + gender + "\n" +
                "Interests: " + interests;

        JOptionPane.showMessageDialog(this, message, "Information Submitted", JOptionPane.INFORMATION_MESSAGE);
    }

    private void clearForm() {
        // Clear all form fields and checkboxes
        firstNameField.setText("");
        lastNameField.setText("");
        addressField.setText("");
        mobileNumberField.setText("");
        maleRadioButton.setSelected(false);
        femaleRadioButton.setSelected(false);
        computerCheckBox.setSelected(false);
        sportsCheckBox.setSelected(false);
        musicCheckBox.setSelected(false);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Q1B();
            }
        });
    }
}
