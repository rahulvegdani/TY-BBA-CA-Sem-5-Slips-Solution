class Country:
    def __init__(self):
        self.country_name = ""

    def accept_country(self):
        self.country_name = input("Enter the country name: ")

    def print_nationality(self):
        print(f"Nationality: {self.country_name}")


class State(Country):
    def __init__(self):
        super().__init__()
        self.state_name = ""

    def accept_state(self):
        self.state_name = input("Enter the state name: ")

    def print_state(self):
        print(f"State: {self.state_name}")

    def print_details(self):
        print(f"Country: {self.country_name}")
        self.print_state()
        self.print_nationality()


# Create an instance of the State class
state_instance = State()

# Input the country and state names
state_instance.accept_country()
state_instance.accept_state()

# Print state, country, and nationality
state_instance.print_details()
