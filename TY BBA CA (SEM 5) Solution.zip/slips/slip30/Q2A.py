import tkinter as tk

def count_occurrences():
    input_string = string_entry.get()
    char_to_count = char_entry.get()

    if not input_string or not char_to_count:
        result_label.config(text="Please enter both a string and a character.")
        return

    count = input_string.count(char_to_count)

    result_label.config(text=f"The character '{char_to_count}' occurs {count} times in the string.")

# Create the main application window
root = tk.Tk()
root.title("Character Occurrence Counter")

# Create and configure GUI elements
string_label = tk.Label(root, text="Enter a string:")
string_label.pack()

string_entry = tk.Entry(root)
string_entry.pack()

char_label = tk.Label(root, text="Enter a character:")
char_label.pack()

char_entry = tk.Entry(root)
char_entry.pack()

count_button = tk.Button(root, text="Count Occurrences", command=count_occurrences)
count_button.pack()

result_label = tk.Label(root, text="")
result_label.pack()

# Start the GUI event loop
root.mainloop()
