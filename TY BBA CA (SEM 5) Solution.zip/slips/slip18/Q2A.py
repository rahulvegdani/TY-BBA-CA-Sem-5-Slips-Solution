a = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]

# Iterate through the list and print elements less than 5
for element in a:
    if element < 5:
        print(element)
