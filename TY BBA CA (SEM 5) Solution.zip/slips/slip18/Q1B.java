import java.io.*;

public class Q1B {
    public static void main(String[] args) {
        String sourceFileName = "source.txt"; // Replace with the source file name
        String targetFileName = "target.txt"; // Replace with the target file name

        try (BufferedReader reader = new BufferedReader(new FileReader(sourceFileName));
             BufferedWriter writer = new BufferedWriter(new FileWriter(targetFileName))) {

            int charCode;
            while ((charCode = reader.read()) != -1) {
                char character = (char) charCode;

                // Check if the character is a letter and change case
                if (Character.isLetter(character)) {
                    if (Character.isUpperCase(character)) {
                        character = Character.toLowerCase(character);
                    } else {
                        character = Character.toUpperCase(character);
                    }
                }
                // Replace digits with '*'
                else if (Character.isDigit(character)) {
                    character = '*';
                }

                writer.write(character);
            }

            System.out.println("File copied with character case transformation and digit replacement.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
