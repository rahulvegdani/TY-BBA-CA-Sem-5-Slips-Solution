import java.util.Scanner;

class AreaCalculator {
    // Method to calculate the area of a circle
    double calculateCircleArea(double radius) {
        return Math.PI * radius * radius;
    }

    // Method to calculate the area of a triangle
    double calculateTriangleArea(double base, double height) {
        return 0.5 * base * height;
    }

    // Method to calculate the area of a rectangle
    double calculateRectangleArea(double length, double width) {
        return length * width;
    }
}

public class Q1A {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        AreaCalculator calculator = new AreaCalculator();

        System.out.println("Select a shape to calculate its area:");
        System.out.println("1. Circle");
        System.out.println("2. Triangle");
        System.out.println("3. Rectangle");
        int choice = input.nextInt();

        switch (choice) {
            case 1:
                System.out.print("Enter the radius of the circle: ");
                double radius = input.nextDouble();
                double circleArea = calculator.calculateCircleArea(radius);
                System.out.println("Area of the circle: " + circleArea);
                break;
            case 2:
                System.out.print("Enter the base of the triangle: ");
                double base = input.nextDouble();
                System.out.print("Enter the height of the triangle: ");
                double height = input.nextDouble();
                double triangleArea = calculator.calculateTriangleArea(base, height);
                System.out.println("Area of the triangle: " + triangleArea);
                break;
            case 3:
                System.out.print("Enter the length of the rectangle: ");
                double length = input.nextDouble();
                System.out.print("Enter the width of the rectangle: ");
                double width = input.nextDouble();
                double rectangleArea = calculator.calculateRectangleArea(length, width);
                System.out.println("Area of the rectangle: " + rectangleArea);
                break;
            default:
                System.out.println("Invalid choice");
        }

        input.close();
    }
}
