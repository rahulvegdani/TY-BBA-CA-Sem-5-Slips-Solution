class Person:
    def __init__(self, name, address):
        self.name = name
        self.address = address

class Employee(Person):
    def __init__(self, name, address, staffed_salary):
        super().__init__(name, address)
        self.staffed_salary = staffed_salary

# Function to input employee details
def input_employee_details():
    name = input("Enter employee's name: ")
    address = input("Enter employee's address: ")
    staffed_salary = float(input("Enter employee's staffed salary: "))
    return Employee(name, address, staffed_salary)

# Main program
n = int(input("Enter the number of employees: "))
employees = []

for i in range(n):
    print(f"\nEnter details for Employee {i + 1}:")
    emp = input_employee_details()
    employees.append(emp)

print("\nEmployee Details:")
for i, emp in enumerate(employees):
    print(f"\nEmployee {i + 1}:")
    print(f"Name: {emp.name}")
    print(f"Address: {emp.address}")
    print(f"Staffed Salary: ${emp.staffed_salary}")
