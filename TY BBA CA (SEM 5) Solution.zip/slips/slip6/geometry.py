# geometry.py

import math

def cube_area(side_length):
    """Calculate the surface area of a cube."""
    return 6 * side_length ** 2

def cube_volume(side_length):
    """Calculate the volume of a cube."""
    return side_length ** 3

def sphere_area(radius):
    """Calculate the surface area of a sphere."""
    return 4 * math.pi * radius ** 2

def sphere_volume(radius):
    """Calculate the volume of a sphere."""
    return (4/3) * math.pi * radius ** 3
