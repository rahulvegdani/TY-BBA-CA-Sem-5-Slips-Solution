import java.util.Scanner;

class NumberIsZeroException extends Exception {
    public NumberIsZeroException(String message) {
        super(message);
    }
}

public class Q1A {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Enter a number: ");
            int number = scanner.nextInt();

            if (number == 0) {
                throw new NumberIsZeroException("Number Is Zero");
            }

            int lastDigit = number % 10;

            while (number >= 10) {
                number /= 10;
            }

            int firstDigit = number;

            int sum = firstDigit + lastDigit;
            System.out.println("Sum of the first and last digits: " + sum);
        } catch (NumberIsZeroException e) {
            System.err.println(e.getMessage());
        } catch (Exception e) {
            System.err.println("Invalid input. Please enter a valid number.");
        } finally {
            scanner.close();
        }
    }
}
