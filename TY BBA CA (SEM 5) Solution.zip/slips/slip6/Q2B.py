import tkinter as tk
from tkinter import font as tkFont

def update_label_font():
    font_name = font_name_var.get()
    font_size = font_size_var.get()
    is_bold = bold_var.get()

    label_font = tkFont.Font(family=font_name, size=font_size, weight=tkFont.BOLD if is_bold else tkFont.NORMAL)
    label.config(font=label_font)

# Create the main window
root = tk.Tk()
root.title("Label Font Style Changer")

# Create a label with an initial font
label_font = tkFont.Font(family="Arial", size=12, weight=tkFont.NORMAL)
label = tk.Label(root, text="Sample Text", font=label_font)
label.pack(pady=10)

# Font Name
font_name_label = tk.Label(root, text="Font Name:")
font_name_label.pack()
font_name_var = tk.StringVar(value="Arial")
font_name_entry = tk.Entry(root, textvariable=font_name_var)
font_name_entry.pack()

# Font Size
font_size_label = tk.Label(root, text="Font Size:")
font_size_label.pack()
font_size_var = tk.IntVar(value=12)
font_size_scale = tk.Scale(root, from_=8, to=24, orient="horizontal", variable=font_size_var)
font_size_scale.pack()

# Bold
bold_var = tk.BooleanVar(value=False)
bold_checkbutton = tk.Checkbutton(root, text="Bold", variable=bold_var)
bold_checkbutton.pack()

# Apply Button
apply_button = tk.Button(root, text="Apply", command=update_label_font)
apply_button.pack(pady=10)

# Start the GUI main loop
root.mainloop()
